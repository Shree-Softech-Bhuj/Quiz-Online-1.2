<?php
/*
	API v5.3 
	Quiz Online - WRTeam.in 
	WRTeam Developers
*/
session_start();
header("Content-Type: application/json");
header("Expires: 0");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
include('library/crud.php');
$db = new Database();
$db->connect();
date_default_timezone_set('Asia/Kolkata');
$db->sql("SET NAMES 'utf8'");
$response = array();
$access_key = "6808";

/*
 	API methods
	------------------------------------
	1. get_categories()
	2. get_subcategory_by_maincategory()
	3. get_questions_by_subcategory()
	4. get_questions_by_category()
	5. report_question()
	6. get_privacy_policy_settings()
	7. user_signup()
	8. upload_profile_image()
	9. update_profile()
	10. get_monthly_leaderboard()
	11. get_random_questions()
	12. set_monthly_leaderboard()
	13. update_fcm_id()
	14. get_random_questions_for_computer()
	15. get_terms_conditions_settings()
	16. get_questions_by_level()
	17. get_monthly_users_score()
	18. get_user_by_id()
	
	functions 
	------------------------------------
	1. get_fcm_id($user_id)
	2. checkBattleExists($match_id)
	3. send_message($token,$data)
*/

// 1. get_categories() - get category details
if(isset($_POST['access_key']) && isset($_POST['get_categories'])){
	/* Parameters to be passed
		access_key:6808
		get_categories:1
		id:31 //{optional}
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['id'])){
		$id = $db->escapeString($_POST['id']);
		$sql = "SELECT *,(SELECT @no_of_subcategories := count(*) from subcategory s WHERE s.maincat_id = c.id and s.status = 1 ) as no_of, if(@no_of_subcategories = 0, (SELECT @maxlevel := MAX(`level`) from question q WHERE c.id = q.category ),@maxlevel := 0) as `maxlevel` FROM `category` c WHERE c.id = $id ORDER By c.row_order + 0 ASC";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			$result[0]['image'] = (!empty($result[0]['image']))?DOMAIN_URL.'category/'.$result[0]['image']:'';
			$response['error'] = "false";
			$response['data'] = $result[0];
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	}else{
		$sql = "SELECT *,(SELECT @no_of_subcategories := count(*) from subcategory s WHERE s.maincat_id = c.id and s.status = 1 ) as no_of, if(@no_of_subcategories = 0, (SELECT @maxlevel := MAX(`level`) from question q WHERE c.id = q.category ),@maxlevel := 0) as `maxlevel` FROM `category` c ORDER By c.row_order ASC";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			for($i=0;$i<count($result);$i++){
				$result[$i]['image'] = (!empty($result[$i]['image']))?DOMAIN_URL.'category/'.$result[$i]['image']:'';
			}
			$response['error'] = "false";
			$response['data'] = $result;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	}
}

// 2. get_subcategory_by_maincategory() - get sub category details
if(isset($_POST['access_key']) && isset($_POST['get_subcategory_by_maincategory'])){
	/* Parameters to be passed
		access_key:6808
		get_subcategory_by_maincategory:1
		main_id:31
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['main_id'])){
		$id = $db->escapeString($_POST['main_id']);
		$sql = "SELECT *,(select max(level) from question where question.subcategory=subcategory.id ) as maxlevel FROM `subcategory` WHERE `maincat_id`='$id' and `status`=1 ORDER BY row_order + 0 ASC";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			for($i=0;$i<count($result);$i++){
				$result[$i]['image'] = (!empty($result[$i]['image']))?DOMAIN_URL.'subcategory/'.$result[$i]['image']:'';
				$result[$i]['maxlevel'] = ($result[$i]['maxlevel'] == '' || $result[$i]['maxlevel'] == null )?'':$result[$i]['maxlevel'];
			}
			$response['error'] = "false";
			$response['data'] = $result;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	}
}

// 3. get_questions_by_subcategory() - get sub category questions
if(isset($_POST['access_key']) && isset($_POST['get_questions_by_subcategory'])){
	/* Parameters to be passed
		access_key:6808
		get_questions_by_subcategory:1
		subcategory:115
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['subcategory'])){
		$id = $db->escapeString($_POST['subcategory']);
		$sql = "SELECT * FROM `question` where subcategory=".$id." ORDER by RAND()";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			for($i=0;$i<count($result);$i++){
				$result[$i]['image'] = (!empty($result[$i]['image']))?DOMAIN_URL.'images/questions/'.$result[$i]['image']:'';
			}
			$response['error'] = "false";
			$response['data'] = $result;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	}
}

// 4. get_questions_by_category() - get category questions
if(isset($_POST['access_key']) && isset($_POST['get_questions_by_category'])){
	/* Parameters to be passed
		access_key:6808
		get_questions_by_category:1
		category:115
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['category'])){
		$id = $db->escapeString($_POST['category']);
		$sql = "SELECT * FROM `question` WHERE category=".$id." ORDER BY id DESC";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			for($i=0;$i<count($result);$i++){
				$result[$i]['image'] = (!empty($result[$i]['image']))?DOMAIN_URL.'images/questions/'.$result[$i]['image']:'';
			}
			$response['error'] = "false";
			$response['data'] = $result;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
	}
	print_r(json_encode($response));
}

//5. report_question() - report a question by user
if(isset($_POST['report_question']) && isset($_POST['access_key']) ){
	/* Parameters to be passed
		access_key:6808
		report_question:1
		question_id:115
		message: Any reporting message
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$question_id = $_POST['question_id'];
	$message = $_POST['message'];
	if(!empty($question_id) && !empty($message)){
		$data = array(
			'question_id'	 => $question_id,
			'message' => $message,
			'date' => date("Y-m-d")//$datetime->format('Y\-m\-d\ h:i:s'),
		);
		// print_r($data);
		// return false;
		
		$db->insert('question_reports',$data);  // Table name, column names and respective values
		$res = $db->getResult();
		
		$response['error'] = false;
		$response['message'] = "Report submitted successfully";
		$response['id'] = $res[0];
	}else{
		$response['error'] = true;
		$response['message'] = "Please fill all the data and submit!";
	}
	print_r(json_encode($response));
}

// 6. get_privacy_policy_settings()
if(isset($_POST['access_key']) && isset($_POST['privacy_policy_settings']) AND $_POST['privacy_policy_settings']==1){
	/* Parameters to be passed
		access_key:6808
		privacy_policy_settings:1
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	if(!empty($_POST['access_key'])){
		$sql = "SELECT * FROM `settings` WHERE type='privacy_policy'";
        $db->sql($sql);
		$res = $db->getResult();
		if(!empty($res)) {
			$response['error'] = "false";
			$response['data'] = $res[0]['message'];
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
	}else{
		$response['error'] = "true";
		$response['message'] = "Please pass all the fields";
	}
	print_r(json_encode($response));
}

// 7. user_signup()
if(isset($_POST['access_key']) && isset($_POST['user_signup'])){
	/*	Parameters to be passed
		access_key:6808
		user_signup:1
		name:Jaydeep Goswami
		email:jaydeepjgiri@yahoo.com
		profile:Image URL
		mobile:7894561230
		type: email / gmail / fb
		fcm_id: xyz123654
		ip_address: 191.1.0.4
		status:1   // 1 - Active & 0 Deactive
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$email = $db->escapeString($_POST['email']);
	$profile = $db->escapeString($_POST['profile']);
	$fcm_id = $db->escapeString($_POST['fcm_id']);
	$name = $db->escapeString($_POST['name']);
	$ip_address = $db->escapeString($_POST['ip_address']);
	$mobile = (isset($_POST['mobile']))?$db->escapeString($_POST['mobile']):'';
	$type = $db->escapeString($_POST['type']);
	$fcm_id = $db->escapeString($_POST['fcm_id']);
	$points = '0';
	$status = '1';

	$sql = "SELECT id,email FROM users WHERE email='$email'";
	$db->sql($sql);
	$res = $db->getResult();
	if(!empty($res))
	{
		// log in..
		if(!empty($email) && !empty($fcm_id)){
			$sql = "UPDATE `users` SET fcm_id='".$fcm_id."' WHERE id=".$res[0]['id'];
			$db->sql($sql);
			$sql = "SELECT * FROM users WHERE email='$email' AND id=".$res[0]['id'];
			$db->sql($sql);
			$res = $db->getResult();
			foreach($res as $row){
				if (filter_var($row['profile'], FILTER_VALIDATE_URL) === FALSE) {
				    // Not a valid URL. Its a image only or empty
				    $tempRow['profile'] = (!empty($row['profile']))?DOMAIN_URL.'uploads/profile/'.$row['profile']:'';
				
				}else{
				    /* if it is a ur than just pass url as it is */
                    $tempRow['profile'] = $row['profile'];
                }
				
				$tempRow['user_id'] = $row['id'];
				$tempRow['name'] = $row['name'];
				$tempRow['email'] = $row['email'];
				$tempRow['mobile'] = $row['mobile'];
				$tempRow['type'] = $row['type'];
				$tempRow['fcm_id'] = $row['fcm_id'];
				$tempRow['points'] = $row['points'];
				$tempRow['ip_address'] = $row['ip_address'];
				$tempRow['status'] = $row['status'];
				$tempRow['date_registered'] = $row['date_registered'];
				$newresult[] = $tempRow;
			}
			$response['error'] = "false";
			$response['message'] = "Successfully logged in";
			$response['data'] = $newresult[0];
		}else{
			$response['error'] = "true";
			$response['message'] = "Please fill all the data and submit!";
		}
	}
	else
	{
		// signup..
		if(!empty($name) && !empty($fcm_id) && !empty($email) && !empty($ip_address)){
			$data = array(
				'name'  => $name,
				'email'	 => $email,
				'profile'	 => $profile,
				'mobile' => $mobile,
				'fcm_id' => $fcm_id,
				'points' => '0',
				'type' => $type,
				'ip_address' => $ip_address,
				'status' => $status
			);
			$db->insert('users',$data);
			$res = $db->getResult();
    		$data = array(
    			'user_id' => "$res[0]",
				'name'  => $name,
				'email'	 => $email,
				'profile'	 => $profile,
				'mobile' => $mobile,
				'fcm_id' => $fcm_id,
				'points' => '0',
				'type' => $type,
				'ip_address' => $ip_address,
				'status' => $status
			);
			$response['error'] = "false";
			$response['message'] = "User Registered successfully";
			$response['data'] = $data;
		}else{
			$response['error'] = "true";
			$response['message'] = "Please fill all the data and submit!";
		}
	}
	print_r(json_encode($response));
}

// 8. upload_profile_image() - upload users profile pic
if(isset($_POST['access_key']) && isset($_POST['upload_profile_image'])){
	/* Parameters to be passed
		access_key:6808
		upload_profile_image:1
		user_id:37
		image: image file
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	// Path to move uploaded files
	$target_path = "uploads/profile/";
	// Folder create if not exists
	if (!is_dir($target_path)){
	    mkdir($target_path, 0777);
	}
	$id = $db->escapeString($_POST['user_id']);
	$old_profile = '';
	
	$sql = "select `profile` from `users` where id = ".$id;
	$db->sql($sql);
	$res = $db->getResult();
	
	if(filter_var($res[0]['profile'], FILTER_VALIDATE_URL) === FALSE) {
	    // Not a valid URL. Its an image only 
	    $old_profile = (!empty($res[0]['profile']))?$target_path.''.$res[0]['profile']:'';
	}
	
	// final file url that is being uploaded
	$file_upload_url = $target_path;

	if (isset($_FILES['image']['name'])) {
		$target_path = $target_path . basename($_FILES['image']['name']);
		
		try {
			// Throws exception incase file is not being moved
			if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
				// make error flag true
				$response['error'] = true;
				$response['message'] = 'Could not move the file!';
			}
			$sql = "UPDATE `users` SET `profile`='".basename($_FILES['image']['name'])."' WHERE `id`=".$id."";
			$db->sql($sql);
			if(!empty($old_profile)){
			    unlink($old_profile);
			}
			
			// File successfully uploaded
			$response['error'] = false;
			$response['message'] = 'File uploaded successfully!';
			$response['file_path'] = DOMAIN_URL.$file_upload_url.basename($_FILES['image']['name']);
			
		} catch (Exception $e) {
			// Exception occurred. Make error flag true
			$response['error'] = true;
			$response['message'] = $e->getMessage();
		}
	} else {
		// File parameter is missing
		$response['error'] = true;
		$response['message'] = 'Not received any file!';
	}
	 
	// Echo final json response to client
	echo json_encode($response);
}

// 9. update_profile() - update user profile
if(isset($_POST['access_key']) && isset($_POST['update_profile'])){
	/* Parameters to be passed
		access_key:6808
		update_profile:1
		email:jaydeepjgiri@yahoo.com
		name:Jaydeep Goswami
		mobile:7894561230
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$email = $db->escapeString($_POST['email']);
	$name = $db->escapeString($_POST['name']);
	
	$sql = "UPDATE `users` SET `name`='".$name."'";
	$sql .= (isset($_POST['mobile']) && !empty($_POST['mobile']))?" ,`mobile`='".$_POST['mobile']."'":"";
	$sql .= " WHERE `email`='".$email."'";
	$db->sql($sql);
	
	$response['error'] = "false";
	$response['message'] = " Profile updated successfully";
	print_r(json_encode($response));
}

// 10. get_monthly_leaderboard()
if(isset($_POST['access_key']) && isset($_POST['get_monthly_leaderboard'])){
	/* Parameters to be passed
		access_key:6808
		get_monthly_leaderboard:1
		date:2019-02-01		// use date format = YYYY-MM-DD
		user_id:54 			// for get current user rank (optional) (login user_id)
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}

	if(empty($_POST['date']) or !isset($_POST['date'])){
		$response['error'] = "true";
		$response['message'] = "Please fill all the data and submit!";
		print_r(json_encode($response));
		return false;
	}
	
	$date = $db->escapeString($_POST['date']);
	$sql = "SELECT monthly_leaderboard.*,users.name,users.profile,users.email,FIND_IN_SET( score, (SELECT GROUP_CONCAT( score ORDER BY score DESC ) FROM monthly_leaderboard where ( month(monthly_leaderboard.date_created) = month('".$date."')) )) AS rank FROM `monthly_leaderboard` INNER JOIN users ON monthly_leaderboard.user_id=users.id where ( month(monthly_leaderboard.date_created) = month('".$date."'))  ORDER BY score DESC";
	$db->sql($sql);
	$res = $db->getResult();

	if(isset($_POST['user_id']) && !empty($_POST['user_id'])){
		$user_id = $db->escapeString($_POST['user_id']);
		$sql = "SELECT id, user_id, score, FIND_IN_SET( score, (SELECT GROUP_CONCAT( score ORDER BY score DESC ) FROM monthly_leaderboard )) AS rank FROM monthly_leaderboard WHERE user_id =".$user_id;
		$db->sql($sql);
		$my_rank = $db->getResult();
		if(!empty($my_rank)){
			$user_rank['my_rank'] = $my_rank[0];
			array_push($res,$user_rank);
			$res = array_reverse($res);
		}
	}

	if(!empty($res)){
		foreach($res as $row){
		    if(isset($row['profile'])){
    		    if(filter_var($row['profile'], FILTER_VALIDATE_URL) === FALSE) {
    			    // Not a valid URL. Its a image only or empty
    			    $row['profile'] = (!empty($row['profile']))?DOMAIN_URL.'uploads/profile/'.$row['profile']:'';
                }
		    }
		    $tempRow[] = $row;
		}
		$response['error'] = "false";
		$response['data'] = $tempRow;
		print_r(json_encode($response));
	}else{
		$response['error'] = "true";
		$response['message'] = "Data not found";
		print_r(json_encode($response));
	}
}

// 11. get_random_questions() // max 10 rows
if(isset($_POST['access_key']) && isset($_POST['get_random_questions'])){
	/* Parameters to be passed
		access_key:6808
		get_random_questions:1
		match_id:your_match_id
		user_id_1:1010
		fcm_id_1:xyzCode
		user_id_2:1001
		fcm_id_2:pqrsCode
		destroy_match:0 / 1
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$match_id = $db->escapeString($_POST['match_id']);
	
	if(isset($_POST['destroy_match']) && $_POST['destroy_match'] == 1){
	    $sql = "DELETE FROM `battle_questions` WHERE `match_id` = '".$match_id."'";
	    $db->sql($sql);
        $response['error'] = "false";
        $response['message'] = "Battle destroyed successfully";
        print_r(json_encode($response));
        return false;
        exit();
	}
	
	$user_id_1 = $db->escapeString($_POST['user_id_1']);
	$user_id_2 = $db->escapeString($_POST['user_id_2']);
	
	$fcm_id_1 = (isset($_POST['fcm_id_1']))?$_POST['fcm_id_1']:'';
	$fcm_id_2 = (isset($_POST['fcm_id_2']))?$_POST['fcm_id_2']:'';
	
	if(empty($fcm_id_1)){
	    $fcm_id_1 = get_fcm_id($user_id_1);
	}
	if(empty($fcm_id_2)){
	    $fcm_id_2 = get_fcm_id($user_id_2);
	}
	
	if(!checkBattleExists($match_id)){
	    /* if match does not exist read and store the questions */
	    
    	$sql = "SELECT * FROM `question` ORDER BY RAND() LIMIT 0,10";
    	$db->sql($sql);
    	$res = $db->getResult();	
    	
    	if(empty($res)){
    		$response['error'] = "true";
    		$response['message'] = "No questions found to compete with each other!";
    		print_r(json_encode($response));
    	}else{
    		$questions = $db->escapeString(json_encode($res));
    		$sql = "INSERT INTO `battle_questions` (`match_id`, `questions`) VALUES ('$match_id','$questions')";
    		$db->sql($sql);
    // 		echo $sql;
    		
    		foreach($res as $row){
    		    $row['image'] = (!empty($row['image']))?DOMAIN_URL.'images/questions/'.$row['image']:'';
    		    $temp[] = $row;
    		}
    		
    		$res = $temp;
    		
    		$response['error'] = "false";
    		$response['message'] = "Data sent to devices via FCM 1";
    		$response['data'] = $res;
    		
    		$data['data'] = $res;
    // 		$result = send_message($fcm_id_1,$data);
    		$response['user_id_1_status'] = ($result['success'] == 1)?'sent':'not sent';
    		
    // 		$result = send_message($fcm_id_2,$data);
    		$response['user_id_2_status'] = ($result['success'] == 1)?'sent':'not sent';
    		
    		print_r(json_encode($response));
    	}
	}else{
	    /* read the questions and send it. */
	    $sql = "SELECT * FROM `battle_questions` WHERE `match_id` = '".$match_id."'";
	    //echo $sql;
	    $db->sql($sql);
	    $res = $db->getResult();
	    
	    $res = json_decode($res[0]['questions'],1);
	    foreach($res as $row){
		    $row['image'] = (!empty($row['image']))?DOMAIN_URL.'images/questions/'.$row['image']:'';
		    $temp[] = $row;
		}
		$res[0]['questions'] = json_encode($temp);
	    
	    $response['error'] = "false";
		$response['message'] = "Data sent to devices via FCM";
		$response['data'] = json_decode($res[0]['questions']);
		
		$data['data'] = json_decode($res[0]['questions']);
// 		$result = send_message($fcm_id_1,$data);
		$response['user_id_1_status'] = ($result['success'] == 1)?'sent':'not sent';
		
// 		$result = send_message($fcm_id_2,$data);
		$response['user_id_2_status'] = ($result['success'] == 1)?'sent':'not sent';
		
		print_r(json_encode($response));
	}
}

// 12. set_monthly_leaderboard()
if(isset($_POST['access_key']) && isset($_POST['set_monthly_leaderboard'])){
	/* Parameters to be passed
		access_key:6808
		set_monthly_leaderboard:1
		user_id:10
		score:100
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	if(!empty($_POST['access_key']) && !empty($_POST['user_id']) && !empty($_POST['score'])){
		$user_id = $db->escapeString($_POST['user_id']);
		$score = $db->escapeString($_POST['score']);
		$date = date('Y-m-d');
		
		$sql = "SELECT user_id FROM `monthly_leaderboard` WHERE `user_id`=".$user_id." and month(monthly_leaderboard.date_created) = month('".$date."') ";
		$db->sql($sql);
		$result = $db->getResult();
		
		if(!empty($result)){
			$sql = "UPDATE `monthly_leaderboard` SET `score`= `score` + '".$score."' WHERE user_id=".$user_id;
			$db->sql($sql);
			$response['error'] = "false";
			$response['message'] = "successfully update score";
		}else{
			$sql = 'INSERT INTO `monthly_leaderboard` (`user_id`, `score`) VALUES ('.$user_id.','.$score.')';
			$db->sql($sql);
			$response['error'] = "false";
			$response['message'] = "successfully insert score";
		}
	}else{
		$response['error'] = "true";
		$response['message'] = "Please pass all the fields";
	}
	print_r(json_encode($response));
}

// 13. update_fcm_id() - update user FCM ID
if(isset($_POST['access_key']) && isset($_POST['update_fcm_id'])){
	/* Parameters to be passed
		access_key:6808
		update_fcm_id:1
		user_id:1
		fcm_id:xyzCode
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$fcm_id = $db->escapeString($_POST['fcm_id']);
	$id = $db->escapeString($_POST['user_id']);
	
	$sql = "UPDATE `users` SET `fcm_id`='".$fcm_id."'";
	$sql .= " WHERE `id`='".$id."'";
	$db->sql($sql);
	
	$response['error'] = "false";
	$response['message'] = " FCM updated successfully";
	print_r(json_encode($response));
}


// 14. get_random_questions_for_computer() // max 10 rows
if(isset($_POST['access_key']) && isset($_POST['get_random_questions_for_computer'])){
	/* Parameters to be passed
		access_key:6808
		get_random_questions_for_computer:1
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	

    /* if match does not exist read and store the questions */
    
	$sql = "SELECT * FROM `question` ORDER BY RAND() LIMIT 0,10";
	$db->sql($sql);
	$res = $db->getResult();	
	
	if(empty($res)){
		$response['error'] = "true";
		$response['message'] = "No questions found to compete with each other!";
		print_r(json_encode($response));
	}else{
	    $tempRow = array();
		foreach($res as $row){
			$tempRow['id'] = $row['id'];
			$tempRow['category'] = $row['category'];
			$tempRow['subcategory'] =  $row['subcategory'];
			$tempRow['image'] = (!empty($row['image']))?DOMAIN_URL.'images/questions/'.$row['image']:'';
			$tempRow['question'] = $row['question'];
			$tempRow['optiona'] = $row['optiona'];
			$tempRow['optionb'] =  $row['optionb'];
			$tempRow['optionc'] = $row['optionc'];
			$tempRow['optiond'] = $row['optiond'];
			$tempRow['answer'] = $row['answer'];
			$tempRow['level'] =  $row['level'];
			$tempRow['note'] = $row['note'];
			$newresult[] = $tempRow;
		}
		$response['error'] = "false";
		$response['message'] = "Data sent to devices via FCM 1";
		$response['data'] = $newresult;
		print_r(json_encode($response));
	}
}

// 15. get_terms_conditions_settings()
if(isset($_POST['access_key']) && isset($_POST['get_terms_conditions_settings']) AND $_POST['get_terms_conditions_settings']==1){
	/* Parameters to be passed
		access_key:6808
		get_terms_conditions_settings:1
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	if(!empty($_POST['access_key'])){
		$sql = "SELECT * FROM `settings` WHERE type='update_terms'";
        $db->sql($sql);
		$res = $db->getResult();
		if(!empty($res)) {
			$response['error'] = "false";
			$response['data'] = $res[0]['message'];
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
	}else{
		$response['error'] = "true";
		$response['message'] = "Please pass all the fields";
	}
	print_r(json_encode($response));
}


// 16. get_questions_by_level() - get questions by level
if(isset($_POST['access_key']) && isset($_POST['get_questions_by_level'])){
	/* Parameters to be passed
		access_key:6808
		get_questions_by_level:1
		
		level:1
		
		category:115 {or}
		subcategory:115 
		 
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['level']) && (isset($_POST['category']) || isset($_POST['subcategory']))){
		$level = $db->escapeString($_POST['level']);
		$id = (isset($_POST['category']))?$db->escapeString($_POST['category']):$db->escapeString($_POST['subcategory']);
		$sql = "SELECT * FROM `question` WHERE level=".$level;
		$sql .= (isset($_POST['category']))?" and `category`=".$id : " and `subcategory`=".$id;
		$sql .= " ORDER BY id DESC";
		
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			for($i=0;$i<count($result);$i++){
				$result[$i]['image'] = (!empty($result[$i]['image']))?DOMAIN_URL.'images/questions/'.$result[$i]['image']:'';
			}
			$response['error'] = "false";
			$response['data'] = $result;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
	}
	print_r(json_encode($response));
}

// 17. get_monthly_users_score()
if(isset($_POST['access_key']) && isset($_POST['get_monthly_users_score'])){
	/* Parameters to be passed
		access_key:6808
		get_monthly_users_score:1
		user_id:154 			// for get current user rank (optional) (login user_id)
		date:2019-02-01		// use date format = YYYY-MM-DD { optional }
		
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}

	if(isset($_POST['user_id']) && !empty($_POST['user_id'])){
		$user_id = $db->escapeString($_POST['user_id']);
		if(isset($_POST['date'])){
		    /* monthly rank */
		    $date = $db->escapeString($_POST['date']);
		    $sql = "SELECT id, user_id, score, 
		    FIND_IN_SET( score, (SELECT GROUP_CONCAT( score ORDER BY score DESC ) FROM monthly_leaderboard where ( month(monthly_leaderboard.date_created) = month('".$date."')) )) AS rank 
		    FROM monthly_leaderboard WHERE user_id =".$user_id;
		}else{ /* global rank */
		    $sql = "SELECT id, user_id, score, 
		    FIND_IN_SET( score, (SELECT GROUP_CONCAT( score ORDER BY score DESC ) FROM monthly_leaderboard )) AS rank 
		    FROM monthly_leaderboard WHERE user_id =".$user_id;
		}
		
		$db->sql($sql);
		$my_rank = $db->getResult();
		
		if(!empty($my_rank)){
			$response['error'] = "false";
    		$response['data'] = $my_rank[0];
    		print_r(json_encode($response));
		}else{
		    $response['error'] = "true";
    		$response['message'] = "Data not found";
    		print_r(json_encode($response));
		}
	}else{
	    $response['error'] = "true";
		$response['message'] = "Pass all the fields!";
		print_r(json_encode($response));
	}
}

// 18. get_user_by_id() - get user details
if(isset($_POST['access_key']) && isset($_POST['get_user_by_id'])){
	/* Parameters to be passed
		access_key:6808
		get_user_by_id:1
		id:31
	*/
	if($access_key != $_POST['access_key']){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	if(isset($_POST['id'])){
		$id = $db->escapeString($_POST['id']);
		$sql = "SELECT * FROM `users` WHERE id = $id ";
		$db->sql($sql);
		$result = $db->getResult();
		// print_r($result);
		if (!empty($result)) {
			if (filter_var($result[0]['profile'], FILTER_VALIDATE_URL) === FALSE) {
				// Not a valid URL. Its a image only or empty
				$result[0]['profile'] = (!empty($result[0]['profile']))?DOMAIN_URL.'uploads/profile/'.$result[0]['profile']:'';
			
			}else{
				/* if it is a ur than just pass url as it is */
				$result[0]['profile'] = $result[0]['profile'];
			}
			$response['error'] = "false";
			$response['data'] = $result[0];
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	}else{
		$response['error'] = "true";
		$response['message'] = "Please Pass all the fields!";
		print_r(json_encode($response));
	}
}

function get_fcm_id($user_id){
    $db = new Database();
    $db->connect();
    
    $sql = "SELECT `fcm_id` FROM `users` where `id` = ".$user_id;
    $db->sql($sql);
    $res = $db->getResult();
    return $res[0]['fcm_id'];
}

function checkBattleExists($match_id){
    $db = new Database();
    $db->connect();
    
    $sql = "SELECT `id` FROM `battle_questions` where `match_id` = '".$match_id."'";
    $db->sql($sql);
    $res = $db->getResult();
    return $res;
    if(empty($res)){
        return false;
    }else{
        return true;
    }
}

/*firebase send message function*/
function send_message($token,$data){
    $db = new Database();
    $db->connect();
    
	$sql = 'select `fcm_key` from `tbl_fcm_key` where id=1';
	$db->sql($sql);
	$res = $db->getResult();
	
	define('API_ACCESS_KEY', $res[0]['fcm_key']);
	
	$fcmFields = array(
		//  'registration_ids' => $token,  // expects an array of ids
// 		'registration_ids' => array($token),
		'to' => $token,
		'priority' => 'high',
		'data' => $data
	);
	$headers = array(
		'Authorization: key=' . API_ACCESS_KEY,
		'Content-Type: application/json'
	);
	 
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
	curl_setopt( $ch,CURLOPT_POST, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fcmFields ) );
	
	$result = curl_exec($ch );
	curl_close( $ch );
	
	$result = json_decode($result,1);
	return $result;
}

?>